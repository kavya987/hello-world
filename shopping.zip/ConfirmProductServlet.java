package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ConfirmProductServlet
 */
public class ConfirmProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String selectedItems[]=request.getParameterValues("item");
		PrintWriter out= response.getWriter();
		
		if(selectedItems==null) {				
			out.println("<h2>Select atleast one product<h2>");			
			out.println("<h3><a href=Item.html>Go Back</a>");
		}else {
			out.println("<h1>You have selected following Items :");	
			for(String item:selectedItems)
			out.println("<h2>"+item+"</h2>");			
		}
		
	}

}
