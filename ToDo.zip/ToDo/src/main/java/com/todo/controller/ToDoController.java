package com.todo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.todo.model.Login;
import com.todo.model.ToDo;
import com.todo.model.User;
import com.todo.service.LoginService;
import com.todo.service.ToDoService;
import com.todo.service.UserService;

@Controller
public class ToDoController {

	@Autowired
	ToDoService toDoService;

	@Autowired
	UserService userService;

	@Autowired
	LoginService loginService;

	@RequestMapping("/login")
	public ModelAndView loginForm() {
		System.out.println("##########Login###########");
		ModelAndView view = new ModelAndView("loginForm");
		return view;
	}

	@RequestMapping("/validate")
	public ModelAndView validateUser(Login login,HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		
		if (loginService.validateuser(login)) {
			System.out.println("----------------valid");
			String name = request.getParameter("username");
			HttpSession session = request.getSession();
			session.setAttribute("username", name);
			System.out.println("Name: " + name);
			view.setViewName("redirect:/todoList");
			
		}
			
		else {
			System.out.println("----------------invalid");
			view.setViewName("redirect:/login");
		}
		return view;
			
	}

	@RequestMapping("/signUp")
	public ModelAndView signUpForm(User user) {
		System.out.println("##########Sign Up###########");
		ModelAndView view = new ModelAndView("register");

		return view;
	}

	@RequestMapping("/saveUser")
	public ModelAndView saveuser(User user) {
		ModelAndView view = new ModelAndView("loginForm");
		userService.addUser(user);
		Login login = new Login(user.getUsername(), user.getPassword());
		loginService.addUser(login);
		return view;
	}

	@RequestMapping("/todoList")
	public ModelAndView todoList() {
		System.out.println("todoList");
		ModelAndView view = new ModelAndView("todo-list");
		List<ToDo> allTodo = toDoService.ListToDo();
		view.addObject("listTodo", allTodo);
		return view;
	}

	@RequestMapping("/todoForm")
	public ModelAndView todoForm(User user) {
		System.out.println("############todo Form");
		ModelAndView view = new ModelAndView("todo-form");
		return view;
	}

	@RequestMapping("/saveTodo")
	public String saveTodo(ToDo toDo, HttpServletRequest request) {
		System.out.println("##################savetod");
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		toDo.setUsername(username);
		boolean status = Boolean.parseBoolean(request.getParameter("isDone"));
		toDo.setStatus(status);
		toDoService.addToDo(toDo);
		System.out.println(status);
		return "redirect:/todoList";
	}

	@RequestMapping("/deleteTodo/{id}")
	public ModelAndView deleteTodo(@PathVariable("id") Integer id) {
		System.out.println("#######  deleteProduct");
		ModelAndView view = new ModelAndView("redirect:/todoList");
		toDoService.deleteToDo(id);
		return view;

	}

	@RequestMapping("/editTodo/{id}")
	public ModelAndView editTodo(@PathVariable("id") Integer id) {
		System.out.println("#######  editTodo");
		ModelAndView view = new ModelAndView("redirect:/editForm{id}");
		return view;

	}

	@RequestMapping("/editForm{id}")
	public ModelAndView editFrom(@PathVariable("id") Integer id) {
		System.out.println("##################edittod");
		ToDo toDo = toDoService.getTodo(id);
		ModelAndView view = new ModelAndView("todo-form");
		view.addObject("todo", toDo);
		return view;
	}

	@RequestMapping("/updateTodo")
	public String upateTodo(ToDo toDo, HttpServletRequest request) {
		System.out.println("##################updatetod");
		boolean status = Boolean.parseBoolean(request.getParameter("isDone"));
		toDo.setStatus(status);
		toDoService.updateToDo(toDo);
		System.out.println(toDo);
		return "redirect:/todoList";
	}

	@RequestMapping("/logout")
	public ModelAndView logout() {
		System.out.println("############todo Form");
		ModelAndView view = new ModelAndView("redirect:/login");
		return view;
	}

}
